#include "storage.hpp"

namespace configuration
{

CategoryAimbot m_aimbot = { };
CategoryVisuals m_visuals = { };

} // namespace configuration
#pragma once

#include "../../include/auto.hpp"
#include "../../include/base.hpp"
#include "../../include/win32.hpp"

#include "../../memory/base.hpp"

#include "basetypes.hpp"
#include "platform.hpp"

#include <math.h>
#include <stdio.h>
#include <stdarg.h>

#define MFP_SIZE																								( 4 )